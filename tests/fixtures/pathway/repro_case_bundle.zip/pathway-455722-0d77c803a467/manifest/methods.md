# Methods — NO -> NH3 on Pd
Reaction pathways for **NO -> NH3** on a
**Pd(3x3) 4-layer (111) slab** (bottom 2
layers fixed, 10.0 A vacuum) were explored with the *autocatpath* pipeline
(v0.22.0). The `ammonia` reaction network comprised 26 adsorbate
states and 15 elementary steps.
Energies and forces were evaluated with the interatomic
potential(s): **mace:medium** (device: cuda). For each of
2 random seed(s) [0, 1] and each model,
adsorbate poses were perturbed, pre-relaxed, then relaxed with BFGS to a maximum
force of 0.1 eV/A. Transition states were located with
climbing-image NEB (5 images, converged to
0.15 eV/A). Adsorbate states were referenced to the substrate
per run before pooling, so reported values combine **1 model(s) x
2 seed(s) = 2 samples**; all energies and barriers are
means +- 1 standard deviation across those samples. States/barriers whose spread
exceeds 0.05 eV are flagged low-confidence.
States are FULL-SYSTEM energies (gas ledger): a desorbed product stays on the state as a gas molecule (relaxed in the same potential), a parked fragment as an isolated adsorbate (E(X*) - E(clean slab)), and every reservoir atom is debited its chemical potential (mu_H = 1/2 E(H2), mu_N = 1/2 E(N2), mu_O = E(H2O) - 2 mu_H) -- so total composition is identical at every diagram state and supply/desorption links carry their real reaction energy. Competing profiles are ranked by their Kozuch-Shaik energetic span (TDI/TDTS marked on the best route); side branches follow the `diagram.side_products: competitive` policy (margin 0.2 eV). Kinetic traps -- states whose cheapest escape (forward, reverse, or
desorption) climbs higher than the best route's energetic span -- are marked
with a warning sign on the profile and listed under `traps` in results.json.
A four-axis scorecard (`score` in results.json) reports the activity span and
worst-case selectivity / poison / trap margins with their ranked breakdowns;
`limiting_factor` names the binding constraint.
A poison site-competition screen compared the clean-slab adsorption energy of CO against the substrate's, each vs its own gas reference (mean-field, molecular, zero-coverage); the comparison is drawn as a numeric box on the profile figures and listed under `poisons` in results.json. All values are Gibbs free-energy differences at **298.15 K** (all gases at the 1 bar reference), tier `vib`: gases carry experimental ZPE, tabulated standard entropies (NIST-JANAF) with rigid-rotor thermal terms and kT ln(p/p0); adsorbed states carry measured harmonic corrections (finite-difference normal modes of the adsorbate atoms, slab frozen; ZPE + vibrational free energy, soft modes floored at 12 meV); barriers carry their reactant's correction (transition-state corrections await saddle refinement). Uncorrected potential energies are recoverable via `thermo.state_corrections` in results.json. Species without table data were left uncorrected: NH2OH(g) (see `warnings`).
Validation: RDKit sanitisation (molecule-like species), post-relaxation geometry
checks (clashes / desorption), NEB convergence, and cross-seed/model stability.