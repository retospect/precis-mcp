# Methods — NO -> NH3 on Pd

Synthetic placeholder methods text for the repro-case fixture. It stands in for the retained pathway body so the archive stages a methods member with a stable hash.

Nothing here describes a real study; the numbers live in the job and pathway meta.
