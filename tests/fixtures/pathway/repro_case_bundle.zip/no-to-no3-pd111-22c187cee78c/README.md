# Reproducibility bundle: NO → NO3 on Pd(111)

One frozen `autocatpath_seed` run of pathway `no-to-no3-pd111`, packaged for
inspection off-cluster. Every file is SHA-256 checksummed in
`MANIFEST.sha256`; the archive identity (`bundle_id`) is the SHA-256 of that
manifest and rides the zip's root directory name — it is deliberately not a
member (a member holding it would change the manifest it hashes).

## Inspect

- Open `index.html` — the offline evidence index: reported value → output
  field → run/envelope → recorded checks → inputs. No network access needed.
- `evidence-index.json` is the same index machine-readable.
- `ro-crate-metadata.json` describes the crate (RO-Crate 1.3, Process Run
  Crate 0.6 profile).

## Verify integrity

Inside the extracted root directory:

    sha256sum -c MANIFEST.sha256

or, with precis installed (no database needed):

    precis pathway inspect <this-archive>.zip
    precis pathway verify-report <this-archive>.zip \
        --record manifest/pathway_snapshot.json --output-dir <dir>

A modified file fails the checksum pass *before* any compute — the archive
never asks a reader to re-run it.

## Honest limits

- No viewer: the catpath report outdir is not retained by precis, so this
  archive ships the evidence index rather than a reconstructed viewer.
- Weights and the catpath wheel are sha256 *pins*, not payloads — a missing
  or private checkpoint is disclosed, never replayable.
- `provenance/missing.json` is the authoritative list of what the stored
  record does not attest.
- Numerical reproduction is judged by the recorded D10 re-validation in
  `checks/evidence.json`, not by this archive.

## Disclosed gaps

- `env/uv.lock` — not staged in this slice — recorded in D10 lock pin when stamped
- `env/wheels/` — the catpath wheel is private — its sha256/rev is recorded in provenance when stamped, never bundled
- `provenance/code` — not stamped by the seed producer
- `provenance/effective_config` — not stamped by the seed producer
- `provenance/finding` — no finding/nanopub link stamped on the pathway snapshot
- `provenance/image` — not stamped by the seed producer
- `provenance/lock` — not stamped by the seed producer
- `provenance/platform` — not stamped by the seed producer
- `provenance/units` — not stamped by the seed producer
- `provenance/wheel` — not stamped by the seed producer
- `replay` — reproduce.sh/verify.py are a later slice; this archive is inspection evidence, not a certified replay package
- `viewer/` — no retained catpath report outdir — the viewer-less slice (spec decision 1) ships the evidence index instead
